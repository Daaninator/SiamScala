package gamelib;

public class EmptyMouseListener implements SimpleMouseListener {
    @Override
    public void onEvent(int x, int y) {}
}
