package Startup
import java.awt.Graphics2D
import gamelib.Cell
import java.awt.Image
import gamelib.*

class CellPick (xInit: Int, yInit: Int, imgName: String) extends Cell{
  //variables
  var x = xInit
  var y = yInit
  var imgString: String = imgName
  var img = AssetsLoader.loadImage(imgString)
  var width: Int = cellWidth
  var height: Int = cellHeight
  var ownedByPlayer: Char = '/'
  var isCursed = false
  var isMovedCursed = false
  var curseChar = '/'
  var curseImgString = nothingName
  var curseImg = AssetsLoader.loadImage(curseImgString)
  var curseSize:Int = width/5
  var spellCountdown = 2

  def destroyCell(): Unit = {
    if isOlifant(ownedBy()) then playerNeushoorn.addSpell(curseChar)
    else if isNeushoorn(ownedBy()) then playerOlifant.addSpell(curseChar)
    changePng(nothingName)
    ownedByPlayer = '/'
    spellCountdown = 2
    setUncursed()
  }

  def checkIfMoveable(): Boolean = {
    if isMovedCursed then
      spellCountdown != 0
    else true
  }

  def applyCurse(): Unit = {
    if (getIsCursed()) {
      if (curseChar == deadSpellChar) { // dead spell
        if spellCountdown > 0 then spellCountdown -= 1
        else {
          if isOlifant(ownedBy()) then playerOlifant.addOneArrow()
          else if isNeushoorn(ownedBy()) then playerNeushoorn.addOneArrow()
          destroyCell()
        }
      }
      else if (curseChar == quarterTurnSpellChar) { //quarterturn spell
        quarterTurnImg()
      }
    }
  }

  //will update ownedByPlayer variable
  def compareWithImg(inputString: String): Boolean = {
    getImgName().equals(inputString)
  }
  def currentPlayerUpdate(): Unit = {
    if (compareWithImg(olifantUp) || compareWithImg(olifantDown) || compareWithImg(olifantLeft) || compareWithImg(olifantRight)) {
      ownedByPlayer = 'o'
    }
    else if (compareWithImg(neushoornUp) || compareWithImg(neushoornDown) || compareWithImg(neushoornLeft) || compareWithImg(neushoornRight)) {
      ownedByPlayer = 'n'
    }
    else if (compareWithImg(mountainName)) {
      ownedByPlayer = 'M'
    } else {
      ownedByPlayer = '/'
    }
  }

  def ownedBy(): Char = {
    ownedByPlayer
  }
  
  def setMN(m: Int, n: Int): Unit = {
    x = calculateX(n)
    y = calculateY(m)
  }
  def applyMoveCurse(): Unit = {
    spellCountdown -= 1
  }
  def getCurseChar(): Char =
    curseChar
  def getX(): Int =
    x
  def getY(): Int =
    y
  def getImgName(): String =
    imgString
  def isMountain(): Boolean = {
    getImgName().equals(mountainName)
  }
  def isNothing(): Boolean = {
    getImgName().equals(nothingName)
  }
  def isSomething(): Boolean = {
    !isNothing()
  }
  def changePng(pngNew: String): Unit = {
    imgString = pngNew
    img = AssetsLoader.loadImage(imgString)
    currentPlayerUpdate()
  }

  def getDirection(): Char = {
    if (compareWithImg(olifantUp) || compareWithImg(neushoornUp)) then '^'
    else if (compareWithImg(olifantRight) || compareWithImg(neushoornRight)) then '>'
    else if (compareWithImg(olifantDown) || compareWithImg(neushoornDown)) then 'v'
    else if (compareWithImg(olifantLeft) || compareWithImg(neushoornLeft)) then '<'
    else '/'
  }

  def getOppositeDirection(): Char = {
    if (compareWithImg(olifantUp) || compareWithImg(neushoornUp)) then 'v'
    else if (compareWithImg(olifantRight) || compareWithImg(neushoornRight)) then '<'
    else if (compareWithImg(olifantDown) || compareWithImg(neushoornDown)) then '^'
    else if (compareWithImg(olifantLeft) || compareWithImg(neushoornLeft)) then '>'
    else '/'
  }
  def quarterTurnImg(): Unit ={
    val currentDirection = getDirection()
    val currentPlayer = ownedBy()
    if (currentDirection == '^' && isOlifant(currentPlayer)) then changePng(olifantRight)
    if (currentDirection == '>' && isOlifant(currentPlayer)) then changePng(olifantDown)
    if (currentDirection == 'v' && isOlifant(currentPlayer)) then changePng(olifantLeft)
    if (currentDirection == '<' && isOlifant(currentPlayer)) then changePng(olifantUp)

    if (currentDirection == '^' && isNeushoorn(currentPlayer)) then changePng(neushoornRight)
    if (currentDirection == '>' && isNeushoorn(currentPlayer)) then changePng(neushoornDown)
    if (currentDirection == 'v' && isNeushoorn(currentPlayer)) then changePng(neushoornLeft)
    if (currentDirection == '<' && isNeushoorn(currentPlayer)) then changePng(neushoornUp)
  }
  def setCursed(): Unit = {
    isCursed = true
  }
  def setUncursed(): Unit = {
    curseChar ='/'
    isCursed = false
    isMovedCursed = false
  }
  def getIsCursed(): Boolean = {
    isCursed
  }
  def setCurse(theCurse: Char): Unit = {
    setCursed() //cursed on
    curseChar = theCurse
    if (curseChar == deadSpellChar){
      curseImgString = deadName
    }
    else if (curseChar == noMoveSpellChar){
      isMovedCursed= true
      curseImgString = noMoveZoneName
    }
    else if (curseChar == quarterTurnSpellChar) {
      curseImgString = quarterTurnName
    }
    else{
      println("ERROR: wrong curse char in setCurse")
    }
    curseImg = AssetsLoader.loadImage(curseImgString)
  }

  def changeDimensions(widthNew: Int, heightNew: Int): Unit = {
    width = widthNew
    height = heightNew
  }

  override def draw(g: Graphics2D): Unit = { //tekent image op de grid
    g.drawImage(img ,x, y, width, height, null)
    if (getIsCursed()) then g.drawImage(curseImg ,x, y, curseSize, curseSize, null)
  }
}
//object CellPick:
//   