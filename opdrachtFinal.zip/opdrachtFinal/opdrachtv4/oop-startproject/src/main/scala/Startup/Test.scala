package Startup

class Test {
  print("test worked")
  var x: Int = 5
}
