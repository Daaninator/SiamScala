package Startup

import scala.jdk.CollectionConverters.*

class ArrayCells {
  var arrayCells = Array.ofDim[CreateCell](rows, collumns)
  var arrayBigArrowsOlifant: Array[CreateCell] = Array(makeCellBig((screenWidth - bigArrowSize) / 2, 0, bigArrowSize, bigArrowSize, olifantUp),
                                        makeCellBig(screenWidth - bigArrowSize, (screenHeight - bigArrowSize) / 2, bigArrowSize, bigArrowSize, olifantRight),
                                        makeCellBig((screenWidth - bigArrowSize) / 2, screenHeight - bigArrowSize, bigArrowSize, bigArrowSize, olifantDown),
                                        makeCellBig(0, (screenHeight - bigArrowSize) / 2, bigArrowSize, bigArrowSize, olifantLeft))
  var arrayBigArrowsNeushoorn: Array[CreateCell] = Array(makeCellBig((screenWidth - bigArrowSize) / 2, 0, bigArrowSize, bigArrowSize, neushoornUp),
    makeCellBig(screenWidth - bigArrowSize, (screenHeight - bigArrowSize) / 2, bigArrowSize, bigArrowSize, neushoornRight),
    makeCellBig((screenWidth - bigArrowSize) / 2, screenHeight - bigArrowSize, bigArrowSize, bigArrowSize, neushoornDown),
    makeCellBig(0, (screenHeight - bigArrowSize) / 2, bigArrowSize, bigArrowSize, neushoornLeft))
  var arrayChoices: Array[CreateCell] = Array(makeCellBig(calculateX(collumns/2-1), 0, choicesCellSize, choicesCellSize, moveArrowName),
                                            makeCellBig(calculateX(collumns/2), 0, choicesCellSize, choicesCellSize, addArrowName),
                                            makeCellBig(calculateX(collumns/2+1), 0, choicesCellSize, choicesCellSize, turnName))
  var arrayMountains: Array[CreateCell] = Array(makeCellMN(0,0,nothingName),makeCellMN(0,0,nothingName),makeCellMN(0,0,nothingName))
  var arraySpells: Array[CreateCell] = Array(makeCellBig(calculateX(collumns / 2 - 1), screenHeight-choicesCellSize, choicesCellSize, choicesCellSize, quarterTurnName),
                                          makeCellBig(calculateX(collumns / 2), screenHeight-choicesCellSize, choicesCellSize, choicesCellSize, deadName),
                                          makeCellBig(calculateX(collumns / 2 + 1), screenHeight-choicesCellSize, choicesCellSize, choicesCellSize,  noMoveZoneName))
  val returnButton: CreateCell = makeCellBig(0,0,choicesCellSize,choicesCellSize,returnName)
  val elephantCell: CreateCell = makeCellBig(screenWidth-space,0,choicesCellSize,choicesCellSize,elephantName)
  val rhinoCell: CreateCell = makeCellBig(screenWidth-space,0,choicesCellSize,choicesCellSize,rhinoName)
  var listCurseCells: List[CreateCell] = Nil
  var arrayRhinoWin: Array[CreateCell] = Array(makeCellBig(0, 0, screenWidth, screenHeight, rhinoName),
                                              makeCellBig(screenWidth/2-screenWidth/4, 0, screenWidth/2, screenWidth/2, crownName))
  var arrayElephantWin: Array[CreateCell] = Array(makeCellBig(0, 0, screenWidth, screenHeight , elephantName),
                                                makeCellBig(screenWidth / 2 - screenWidth / 4, 0, screenWidth / 2, screenWidth / 2, crownName))

  init() //calls init
  def init(): Unit = {
    //fills array with nothing
    fillArrayCells() //vult arraycells met nothing
    //makes mountains
    initMountains()
    //adds the choices
    addChoices()
    addSpells()
    //add icon of current player
    addPlayerIcon()
    //fills grid with cells
    addCellsToGrid(arrayCells.flatten) //voegt toe aan grid
    }
  def resetCells(): Unit ={
    removeCells(arrayCells.flatten)
    removeChoices()
    removeBigArrows()
    removeReturn()
    removeWinScreen()
    listCurseCells = Nil
    removePlayerIcon()
    init()
  }
  def addPlayerIcon(): Unit ={
    if isOlifant(game.getCurrentPlayer().getPlayerChar()) then addCellToGrid(elephantCell)
    else if isNeushoorn(game.getCurrentPlayer().getPlayerChar()) then addCellToGrid(rhinoCell)
  }
  def removePlayerIcon(): Unit ={
    removeCell(rhinoCell)
    removeCell(elephantCell)
  }
  def initMountains(): Unit ={
    removeCells(arrayMountains)
    arrayMountains(0) = makeCellMN(rows/2, collumns/2-1, mountainName)
    setCell(rows/2, collumns/2-1, arrayMountains(0))
    arrayMountains(1) = makeCellMN(rows/2, collumns/2, mountainName)
    setCell(rows/2, collumns/2, arrayMountains(1))
    arrayMountains(2) = makeCellMN(rows/2, collumns/2+1, mountainName)
    setCell(rows/2, collumns/2+1, arrayMountains(2))
    addCellsToGrid(arrayMountains)
  }
  def addReturn(): Unit =
    addCellToGrid(returnButton)
  def removeReturn(): Unit =
    removeCell(returnButton)
  def addWinScreen(): Unit ={
    if isOlifant(game.getWinnerChar()) then addCellsToGrid(arrayElephantWin)
    else addCellsToGrid(arrayRhinoWin)
  }
  def removeWinScreen(): Unit ={
    removeCells(arrayElephantWin)
    removeCells(arrayRhinoWin)
  }
  def addSpells(): Unit ={
    if game.getCurrentPlayer().hasSpell(quarterTurnSpellChar) then addCellToGrid(arraySpells(0))
    if game.getCurrentPlayer().hasSpell(deadSpellChar) then addCellToGrid(arraySpells(1))
    if game.getCurrentPlayer().hasSpell(noMoveSpellChar) then addCellToGrid(arraySpells(2))

  }
  def removeSpells(): Unit ={
    removeCells(arraySpells)
  }
  def addCurseCell(m:Int, n:Int): Unit ={
    listCurseCells = getCell(m, n) :: listCurseCells
  }
  def applyCurses(): Unit ={
    var oldLst = listCurseCells
    var newLst: List[CreateCell] = Nil
    while (!oldLst.isEmpty){
      if (oldLst.head.getIsCursed()) {
        oldLst.head.applyCurse()
        newLst = oldLst.head :: newLst
      }
      oldLst = oldLst.tail
    }
    listCurseCells = newLst
  }
  def addChoices():Unit =
    addCellToGrid(arrayChoices(0))
    if (game.getCurrentPlayer().canPlaceOne()){
      addCellToGrid(arrayChoices(1))
    }
    addCellToGrid(arrayChoices(2))
  def removeChoices(): Unit=
    removeCells(arrayChoices)

  def addSingleBigArrow(index:Int): Unit = //add left big arrow
    if isOlifant(game.getCurrentPlayerChar()) then
      addCellToGrid(arrayBigArrowsOlifant(index))
    else
      addCellToGrid(arrayBigArrowsNeushoorn(index))

  def addBigArrowUp(): Unit = //add left big arrow
    addSingleBigArrow(0)
  def addBigArrowRight(): Unit = //add left big arrow
    addSingleBigArrow(1)
  def addBigArrowDown(): Unit = //add left big arrow
    addSingleBigArrow(2)
  def addBigArrowLeft(): Unit = //add left big arrow
    addSingleBigArrow(3)  
      
  def addBigArrows(): Unit = //add big arrows to grid
    if isOlifant(game.getCurrentPlayerChar()) then
      addCellsToGrid(arrayBigArrowsOlifant)
    else
      addCellsToGrid(arrayBigArrowsNeushoorn)
  def removeBigArrows(): Unit =
    if isOlifant(game.getCurrentPlayerChar()) then
      removeCells(arrayBigArrowsOlifant)
    else
      removeCells(arrayBigArrowsNeushoorn)

  def makeAndReplaceCell(m: Int, n: Int, pngName: String): Unit = {
    removeCell(getCell(m,n))
    setCell(m,n, CreateCell(calculateX(n), calculateY(m), pngName)) //the new cell
    addCellToGrid(getCell(m,n))
  }
  def printArray():Unit={
    println()
    for (cells <- arrayCells){
      print("[ ")
      for (element <- cells) {
        print(s"${element.ownedBy()} ")
      }
      print("]\n")
    }
  }
  def makeAndWriteOverCell(m: Int, n: Int, pngName: String): Unit = {
    setCell(m, n, CreateCell(calculateX(n), calculateY(m), pngName)) //the new cell
    addCellToGrid(getCell(m, n))
  }
  def addCellsToGrid(cells: Array[CreateCell]): Unit = {
    grid.addCells(cells.toList.asJava)
  }

  def addCellToGrid(cell: CreateCell): Unit = {
    grid.addCells(List(cell).asJava)
  }
  def fillArrayCells(): Unit =
    for (m <- 0 to rows-1){
      for (n <- 0 to collumns-1){
        setCell(m,n, CreateCell(n*cellWidth, m*cellHeight, nothingName))
      }
    }
  def removeCells(cells: Array[CreateCell]): Unit = {
    for (cell <- cells){
      removeCell(cell)
    }
  }
  def removeCell(cellOld: CreateCell): Unit = {
    if (cellOld.getIsCursed()) {
      if (isOlifant(cellOld.ownedBy())) then playerNeushoorn.addSpell(cellOld.getCurseChar())
      else if (isNeushoorn(cellOld.ownedBy())) then playerOlifant.addSpell(cellOld.getCurseChar())
    }
    cellOld.setUncursed() //uncurse it
    grid.removeCell(cellOld)
  }
  def makeCellMN(m: Int, n: Int, pngName: String): CreateCell = {
    CreateCell(calculateX(n), calculateY(m), pngName)
  }
  def makeCellBig(x: Int, y: Int, width: Int, height: Int, pngName: String): CreateCell = {
    val cell: CreateCell = CreateCell(x, y, pngName)
    cell.changeDimensions(width, height)
    return cell
  }
  def getCell(m:Int,n:Int): CreateCell={
    if checkInBounds(m,n) then
      arrayCells(m)(n)
    else
      println("ERROR: out of bounds in get cell")
      arrayCells(0)(0)
  }
  
  def setCell(m: Int, n: Int, value: CreateCell): Unit = {
    if checkInBounds(m,n) then arrayCells(m)(n) = value
    else println("ERROR: out of bounds in set cell")
  }
  def isCellCursed(m:Int, n:Int): Boolean={
    getCell(m,n).getIsCursed()
  }
  def addCurseCell(m:Int, n:Int, curseChar:Char): Unit ={
    getCell(m,n).setCurse(curseChar)
  }
  def getOwnerOfCell(m:Int,n:Int):Char={
    getCell(m,n).ownedBy()
  }
  def isPlayerCell(m:Int,n:Int):Boolean={
    (isOlifant(getOwnerOfCell(m,n)) || isNeushoorn(getOwnerOfCell(m,n)))
  }
  def checkIfPlayerWon(cell: CreateCell):Boolean={
    if cell.isMountain() then true
    else false
  }
  //everything for moveByOne
  def moveByOne(m: Int, n: Int, direction: Char): Unit =  {
    var mPlus = 0
    var nPlus = 0
    var mCurrent = m
    var nCurrent = n
    var lastPlayerChar = '/'
    if (direction=='^'){
      mPlus = -1
    }
    else if (direction=='v'){
      mPlus = 1
    }
    else if (direction == '>') {
      nPlus = 1
    }
    else if (direction == '<') {
      nPlus = -1
    }
    var tempOld = makeCellMN(m, n, nothingName)
    var tempNew = getCell(mCurrent,nCurrent)

      while (mCurrent < rows && mCurrent >= 0 && nCurrent < collumns && nCurrent >= 0) { //stop conditions
        tempNew = getCell(mCurrent,nCurrent) //remembers old value
        setCell(mCurrent,nCurrent,tempOld) //changes cell in arrayCells
        tempOld.setMN(mCurrent, nCurrent) //changes cell new location
        tempOld = tempNew
        if (tempNew.isNothing()) { //is nothing so doesnt need to go farther
          mCurrent = -1 //breaks out of while loop
          nCurrent = -1
          removeCell(tempNew) // remove empty cell from grid
        }
        if (tempNew.getDirection() == direction) then lastPlayerChar = tempNew.ownedBy()
        mCurrent += mPlus
        nCurrent += nPlus

        if (!checkInBounds(mCurrent,nCurrent)){ //at the end, cell needs to be deleted that is pushed off
          removeCell(tempOld)
          if isOlifant(tempOld.ownedBy()) then playerOlifant.addOneArrow() //add arrow to player if lost
          else if isNeushoorn(tempOld.ownedBy()) then playerNeushoorn.addOneArrow()
          if checkIfPlayerWon(tempOld) then game.playerWon(lastPlayerChar) //player won game
        }
      }
  }
}
