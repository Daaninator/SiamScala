package Startup

import gamelib.AssetsLoader

class CreateCell(xInit: Int, yInit: Int, imgNameInit: String) extends CellPick(xInit, yInit, imgNameInit) {

  init() //calls init when cell is created
  def init(): Unit = {
    currentPlayerUpdate()
  }
 
}
