package Startup

import gamelib.GUI
import scala.jdk.CollectionConverters.*

val gui = new GUI(screenWidth, screenHeight, collumns, rows, space)
val grid = gui.getGridPanel
var playerOlifant: Player = new Player('o')
var playerNeushoorn: Player = new Player('n')
var game: GameLogic = new GameLogic
val cells: ArrayCells = new ArrayCells

def isOlifant(compareChar:Char):Boolean={
  compareChar=='o'
}
def isNeushoorn(compareChar:Char):Boolean={
  compareChar=='n'
}
def calculateN(x: Int): Int = //berekent de nde plaats in de cellarray
  val n = Math.floor((x-space) / cellWidth).toInt
  if n<0||n>=collumns then 0
  else n  
def calculateM(y: Int): Int =
  val m = Math.floor((y-space) / cellHeight).toInt
  if m < 0 || m >= rows then 0
  else m
def calculateX(n: Int): Int =
  n*cellWidth+space
def calculateY(m: Int): Int =
  m*cellHeight+space
def checkInBounds(m:Int,n:Int):Boolean={
  (m < collumns && m >= 0 && n < rows && n >= 0)
}
def getOppositeDirection(direction:Char): Char = {
  if direction=='^' then 'v'
  else if direction=='>' then '<'
  else if direction=='v' then '^'
  else if direction=='<' then '>'
  else '/'
}
object StartupMain {
  def main(args: Array[String]) = {
    grid.setReleaseListener(new MyMouseListener)
  }
}
/*
RULES:
 There are 2 players.
  The Rhino (brown arrows) and the Elephant (yellow arrows)

  The objective of each player is to push 1 mountain off the board. The first player that succeeds in this, wins the game.

  Every turn a player can do one of these four things:
  -Add an arrow (only 5 arrows of a player allowed on the board)
  -Move an arrow
  -Turn an arrow
  -Use a potion on an arrow of the opposite player

  There are 3 potions and each player can use each potion only once. The potions' functions are:
  -Turn an arrow every turn by 90 degrees
  -Remove the arrow from the board after 2 turns
  -Allow the arrow to be only moved 2 times

  The player will get the potion again if the 'infected' arrow gets removed from the board.

  You can move 1 or more arrows with a different arrow if the arrow has enough pushing power. To achieve this, there must be a majority of animals pushing in the same direction. An animal can push as many animals as possible if they aren't orientated in the opposite direction.

  The player can counter this by adding arrows in the opposite direction.
*/

