package Startup
import scala.math

class Player(playerChar: Char) {
  var pngs: Array[String] = Array()
  var count: Int = _
  var countDeadSpell = maxSpellsPerPlayer
  var countQuarterMoveSpell = maxSpellsPerPlayer
  var countNoMoveSpell = maxSpellsPerPlayer
  var hasCursedCount:Int = _
  init() //calls init()
  def init():Unit = {
    count = maxArrowsPerPlayer
    countDeadSpell = maxSpellsPerPlayer
    countQuarterMoveSpell = maxSpellsPerPlayer
    countNoMoveSpell = maxSpellsPerPlayer
    if (playerChar == 'o') //then olifant
      pngs = Array(olifantUp, olifantRight, olifantDown, olifantLeft)
    else if (playerChar == 'n') //neushoorn
      pngs = Array(neushoornUp, neushoornRight, neushoornDown, neushoornLeft)
    else
      println("wrong input char in Player")
  }
  def resetPlayer(): Unit = {
    count = maxArrowsPerPlayer
  }
  def getCursedCount(): Int = {
    hasCursedCount
  }
  def hasSpell(curseChar:Char): Boolean = {
    if (curseChar == deadSpellChar) {
      countDeadSpell != 0
    }
    else if (curseChar == noMoveSpellChar) {
      countNoMoveSpell != 0
    }
    else if (curseChar == quarterTurnSpellChar) {
      countQuarterMoveSpell != 0
    }
    else {
      println("ERROR: wrong curse char in hasSpell in player")
      false
    }
  }
  def addSpell(curseChar: Char): Unit ={
    if (curseChar == deadSpellChar) {
      countDeadSpell += 1
    }
    else if (curseChar == noMoveSpellChar) {
      countNoMoveSpell += 1
    }
    else if (curseChar == quarterTurnSpellChar) {
      countQuarterMoveSpell += 1
    }
    else {
      println("ERROR: wrong curse char in usedSpell in player")
    }
  }
  def usedSpell(curseChar: Char): Unit = {
    if (curseChar == deadSpellChar) {
      countDeadSpell -= 1
    }
    else if (curseChar == noMoveSpellChar) {
      countNoMoveSpell -= 1
    }
    else if (curseChar == quarterTurnSpellChar) {
      countQuarterMoveSpell -= 1
    }
    else {
      println("ERROR: wrong curse char in usedSpell in player")
    }
  }
  def getPng(index:Int):String={
    pngs(index)
  }
  def canPlaceOne():Boolean={
    if count > 0 then true
    else
      println(s"Arrow limit reached for this player")
      false
  }
  def addOneArrow(): Unit ={
    count+=1
  }
  def placedOne():Unit={
    count -= 1
  }
  def getPlayerChar():Char={
    playerChar
  }
  def isPlayerOlifant():Boolean={
    getPlayerChar()=='o'
  }
  def getDirection(direction: Char): String = {
    var index = 0
    if direction == '^' then index = 0
    else if direction == '>' then index = 1
    else if direction == 'v' then index = 2
    else if direction == '<' then index = 3
    getPng(index)
  }
  def getOppositDirection(direction: Char): String = {
    var index = 0
    if direction == '^' then index = 2
    else if direction == '>' then index = 3
    else if direction == 'v' then index = 0
    else if direction == '<' then index = 1
    getPng(index)
  }
}
