package Startup
import scala.math

class GameLogic {
  var progressTurn: Int = _
  var currentPlayer = playerOlifant
  var pngName: String = _
  var currentDirection: Char = _
  var currentChoice: Char = _
  var rememberM: Int = _
  var rememberN: Int = _
  var gameOver: Boolean = _
  var playerWinner: Char = _
  
  init()
  def init(): Unit ={
    progressTurn = 0
    pngName = olifantUp
    currentPlayer = playerOlifant
    currentDirection = '/'
    currentChoice = '/'
    rememberM = 0
    rememberN = 0
    playerWinner = '/'
    gameOver = false

  }

  def nextTurn(): Unit = { //next player turn function
    if (gameOver) {
      cells.addWinScreen()
    }
    else {
      progressTurn = 0 //beginturn
      if (currentPlayer.isPlayerOlifant()) {
        currentPlayer = playerNeushoorn
        pngName = currentPlayer.getPng(0)
      } else {
        currentPlayer = playerOlifant
        pngName = currentPlayer.getPng(0)
      }
      cells.addPlayerIcon() //add current player iconm
      cells.applyCurses() //apply all the curses that are in the game
      cells.removeReturn() //removes reutrn button
      cells.addChoices() //add choices to screen
      cells.addSpells()
      // cells.printArray() //print array in console
    }
  }

  def getCurrentPlayerChar(): Char =
    currentPlayer.getPlayerChar()

  def getCurrentPlayer(): Player =
    currentPlayer
  def clickedReturnCheck(x:Int,y:Int):Boolean={
    (x<choicesCellSize && y<choicesCellSize)
  }
  def choosePNG(index: Int): Unit = { // chooses correct png of the current player
    pngName = currentPlayer.getPng(index)

  }
  def tryAddBigArrows(m:Int, n:Int, changeDirection:Boolean): Boolean = {
    var bool = false
    val offset = if changeDirection then 0 else 1

    currentDirection = '^'
    if checkIfMovePossible(m-offset,n,changeDirection) then
      cells.addBigArrowUp()
      bool=true
    currentDirection = '>'
    if checkIfMovePossible(m,n+offset,changeDirection) then
      cells.addBigArrowRight()
      bool=true
    currentDirection = 'v'
    if checkIfMovePossible(m+offset, n,changeDirection) then
      cells.addBigArrowDown()
      bool=true
    currentDirection = '<'
    if checkIfMovePossible(m, n-offset,changeDirection) then
      cells.addBigArrowLeft()
      bool=true
    return bool
  }
  def getWinnerChar(): Char ={
    playerWinner
  }
  def playerWon(playerWonChar:Char): Unit ={
    var playerName: String = "/"
    progressTurn = -1
    if isOlifant(playerWonChar) then
      playerName = "Yellow"
      playerWinner = 'o'
    else 
      playerName = "Brown"
      playerWinner = 'n'
    for (i<-0 to 10) {
      println(s"-- player ${playerName} won --")
    }
    gameOver = true
  }
  def resetGame(): Unit ={
    init()
    playerNeushoorn.resetPlayer()
    playerOlifant.resetPlayer()
    cells.resetCells()
  }
  def checkIfEnoughPower(m:Int,n:Int, powerInit:Int):Boolean={ //checks if enough power to move
    val oppositeCheck = getOppositeDirection(currentDirection)
    val check = currentDirection
    var power: Int = powerInit
    var jPlus = 0
    var iPlus = 0
    var j = n
    var i = m
    var countMountains = 0
    if currentDirection == '<' then
      jPlus = -1
    else if currentDirection == '>' then
      jPlus = 1
    else if currentDirection == '^' then
      iPlus = -1
    else if currentDirection == 'v' then
      iPlus = 1

    //special case if you move an old cell
    if (powerInit == 0){
      if (checkInBounds(i,j) && cells.getCell(i,j).isNothing()) then
        return true
      i -= iPlus //correct the minus you did in BigArrows
      j -= jPlus
    }
    while (checkInBounds(i,j)) {
      if cells.getCell(i,j).getDirection() == check then
        power += 1
      else if cells.getCell(i,j).getDirection()== oppositeCheck then 
        power -= 1
        if power <= 0 then return false
      else if cells.getCell(i,j).isNothing() then return power > 0 //if bigger than 0 then enoguh power to move
      else if (cells.getCell(i,j).isMountain()) {
        if countMountains == 0 then countMountains = 1
        else power -= 1
      }
      j += jPlus
      i += iPlus
    }
    return power > 0
  }
  def checkIfCanPlaceOnOccupied(m:Int, n:Int): Boolean = { //will check if it's possible ofr the player to set an arrow if it's already occupied
    if (cells.getCell(m,n).isSomething()){
      if (m==0) {
        if (currentDirection == 'v') then return true
        else if (n==0) {
          if (currentDirection == '>') then return true
        }
        else if (n==collumns-1) {
          if (currentDirection == '<') then return true
        }
      }
      else if (m==collumns-1) {
        if (currentDirection == '^') then return true
        else if (n == 0) {
          if (currentDirection == '>') then return true
        }
        else if (n == collumns - 1) {
          if (currentDirection == '<') then return true
        }
      }
      else if (n==0){
        if (currentDirection == '>') then return true
      }
      else if (n==collumns-1){
        if (currentDirection == '<') then return true
      }
    }else{
      return true
    }
    return false //is when space is occupied but arrow is not at the right direction
  }

  def checkIfMovePossible(m: Int, n: Int, newMove:Boolean): Boolean = {
    if checkInBounds(m,n) then
      if !newMove then //if it's an old cell you move
        checkIfEnoughPower(m, n, 0)
      else (checkIfCanPlaceOnOccupied(m, n) && checkIfEnoughPower(m, n, 1)) //new cell you want to add
    else false
  }

  def tryClick(x: Int, y: Int): Unit = {
    val m: Int = calculateM(y)
    val n: Int = calculateN(x)

    if (clickedReturnCheck(x, y) && progressTurn != 0) { //if clicked on return button
      progressTurn = 0
      cells.removeBigArrows()
      cells.addChoices()
      cells.addSpells()
      cells.removeReturn()
    }
    if (progressTurn == 0){ //choose choices
      if (x > calculateX(collumns/2-1) && x < calculateX(collumns/2) && y < choicesCellSize){ //move cell
        currentChoice = moveChar
        applyClick(m, n)
      }
      else if (x > calculateX(collumns/2) && x < calculateX(collumns/2+1) && y < choicesCellSize){ //choose arrow
        if (currentPlayer.canPlaceOne()) {
          currentChoice = addArrowChar
          applyClick(m, n)
        }
      }
      else if (x > calculateX(collumns / 2 +1) && x < calculateX(collumns / 2 + 2) && y < choicesCellSize) { //rechoose direction
        currentChoice = changeDirectionChar
        applyClick(m, n)
      }
      else if (x > calculateX(collumns / 2 - 1) && x < calculateX(collumns / 2) && y > screenHeight - choicesCellSize && getCurrentPlayer().hasSpell(quarterTurnSpellChar)) { //quarter movement each turn spell
        currentChoice = quarterTurnSpellChar
        applyClick(m, n)
      }
      else if (x > calculateX(collumns / 2) && x < calculateX(collumns / 2 + 1) && y > screenHeight - choicesCellSize && getCurrentPlayer().hasSpell(deadSpellChar)) { //dead spell
        currentChoice = deadSpellChar
        applyClick(m, n)

      }
      else if (x > calculateX(collumns / 2 + 1) && x < calculateX(collumns / 2 + 2) && y > screenHeight - choicesCellSize && getCurrentPlayer().hasSpell(noMoveSpellChar)) { //no movement spell
        currentChoice = noMoveSpellChar
        applyClick(m, n)
      }
    }
    else if (progressTurn == 1){ //choose cell you want to place cell
      if (m == 0 || m == rows - 1 || n == 0 || n == collumns - 1){
        rememberM = m
        rememberN = n
        applyClick(m, n)
      } else {
        println(s"ERROR: wrong place click on m = ${m} and n = ${n}")
      }
    }
    else if (progressTurn == 2 || progressTurn == 12 || progressTurn == 22) { //choose arrow
      if ((x > (screenWidth - bigArrowSize) / 2 && x < (screenWidth + bigArrowSize) / 2) && y < bigArrowSize) { //up
        choosePNG(0)
        currentDirection = '^'
        applyClick(rememberM, rememberN)
      } else if (x > screenWidth - bigArrowSize && (y < (screenHeight + bigArrowSize) / 2 && y > (screenHeight - bigArrowSize) / 2)) { //right
        choosePNG(1)
        currentDirection = '>'
        applyClick(rememberM, rememberN)
      } else if ((x > (screenWidth - bigArrowSize) / 2 && x < (screenWidth + bigArrowSize) / 2) && y > (screenHeight - bigArrowSize)) { //down
        choosePNG(2)
        currentDirection = 'v'
        applyClick(rememberM, rememberN)
      } else if (x < bigArrowSize && y < (screenHeight + bigArrowSize) / 2 && y > (screenHeight - bigArrowSize) / 2) { //left
        choosePNG(3)
        currentDirection = '<'
        applyClick(rememberM, rememberN)
      }
    }
    else if (progressTurn == 3) { //can place arrow
      if ((m == 0 || m == rows - 1 || n == 0 || n == collumns - 1) && checkIfMovePossible(m, n,true)) { //clicked up or under
        applyClick(m, n)
      } else {
        println(s"wrong place click on m = ${m} and n = ${n}")
      }
    }
    else if (progressTurn == 11 || progressTurn == 21){
      if (cells.getCell(m,n).checkIfMoveable()) { //for curse
        if (cells.getOwnerOfCell(m, n) == getCurrentPlayerChar()) {
          rememberM = m
          rememberN = n
          applyClick(m, n)
        }
        else {
          println(s"ERROR: cell on m = ${m} and n = ${n} is not current players cell")
        }
      }
    }
    else if (progressTurn == 31){
      if (cells.getOwnerOfCell(m,n) != getCurrentPlayerChar() && cells.isPlayerCell(m,n) && !cells.isCellCursed(m,n)){ //if this all true than you can apply a curse to the cell
        rememberM = m
        rememberN = n
        applyClick(m, n)
      }
    }
    else if (gameOver){ //new game begins
      resetGame()
    }
  }
  def applyClick(m: Int, n: Int): Unit = { //applied click
    if (progressTurn == 0) { //1 of 3 options is chosen
      var somethingHasBeenChosen = false
      if (currentChoice == moveChar) { //move already existing cell
        progressTurn = 21
        somethingHasBeenChosen=true
      }
      else if (currentChoice == addArrowChar) { //choose 1 of 4 arrows choice
        progressTurn = 1
        somethingHasBeenChosen=true
      }
      else if (currentChoice == changeDirectionChar){
        progressTurn = 11
        somethingHasBeenChosen=true
      }
      else if (currentChoice == deadSpellChar || currentChoice == noMoveSpellChar || currentChoice == quarterTurnSpellChar){ //the spells
        progressTurn = 31
        somethingHasBeenChosen = true
      }
      if (somethingHasBeenChosen){ //removes all the choices from grid
        cells.removeChoices()
        cells.removeSpells()
        cells.addReturn()
      }
    }
    //if you want add a new cell to the border (V)
    else if (progressTurn == 1){ //cell just chosen
      if (tryAddBigArrows(m,n,true)) { //if you can add atleast 1 arrow then next turn
        progressTurn = 2
      }
    }
    else if (progressTurn == 2){//direction of arrow chosen
      if (checkIfMovePossible(rememberM, rememberN, true)) {
        applyRules(m, n) //applies the rules, like moving arrows if needed
        cells.makeAndReplaceCell(m, n, pngName)
        cells.removeBigArrows() //removed big arrows
        currentPlayer.placedOne() //placed an arrow -> minus 1 arrow of total
        nextTurn() //volgende speler zijn beurt
        }
    }
    //if you want to apply new direction to cell (@)
    else if (progressTurn == 11){ //choose cell
      cells.addBigArrows()
      progressTurn = 12
    }
    else if (progressTurn == 12) { //apply new direction
      val directionPng = currentPlayer.getDirection(currentDirection)
      cells.getCell(m,n).changePng(directionPng)
      cells.removeBigArrows()
      nextTurn()
    }
    // if you want move existing cell   (M)
    else if (progressTurn==21){ //clicked on existing cell
      if (tryAddBigArrows(m, n,false)) { //if you can add atleast 1 arrow then next turn
        progressTurn = 22
      }
    }
    else if (progressTurn==22){
      if cells.getCell(m,n).isMovedCursed then cells.getCell(m,n).applyMoveCurse() //applies move curse if needed
      applyRules(m, n) //applies the rules, like moving arrows if needed
      cells.makeAndWriteOverCell(m, n, nothingName)
      cells.removeBigArrows() //removed big arrows
      nextTurn() //volgende speler zijn beurt
    }
    else if (progressTurn==31){ //spells start
      cells.addCurseCell(m, n, currentChoice)
      getCurrentPlayer().usedSpell(currentChoice)
      cells.addCurseCell(m,n)
      nextTurn()
    }
  }

  def applyRules(m: Int, n: Int): Unit = {
    val currentCell = cells.getCell(m,n)
    if (currentCell.isSomething()) {
      cells.moveByOne(m, n, currentDirection)
    }

  }
}
