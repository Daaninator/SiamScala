package Startup

val rows: Int = 5
val collumns: Int = 5
val space: Int = 150
val screenWidth: Int = 1000
val screenHeight: Int = 1000
val cellWidth: Int = (screenWidth-space*2)/collumns
val cellHeight: Int = (screenHeight-space*2)/rows
val bigArrowSize = 150
val maxArrowsPerPlayer = 5
val maxSpellsPerPlayer = 1
//pngs
val mountainName = "bergen.png"
val nothingName = "nothing.png"
val moveArrowName = "arrows.png"
val turnName = "quarterMovement.png"
val deadName = "onverwachte_dood.png"
val quarterTurnName =  "ongecontroleerd_draaien.png"
val noMoveZoneName = "beperkte_bewegingsvrijheid.png"
val neushoornUp = "neushoorn_up.png"
val neushoornDown = "neushoorn_down.png"
val neushoornRight = "neushoorn_right.png"
val neushoornLeft = "neushoorn_left.png"
val olifantUp = "olifant_up.png"
val olifantDown = "olifant_down.png"
val olifantRight = "olifant_right.png"
val olifantLeft = "olifant_left.png"
val addArrowName = "addArrow.png"
val returnName = "return.png"
val rhinoName = "rhino.jpg"
val elephantName = "elephant.jpg"
val crownName = "crown.png"
//option chars
val moveChar = 'M'
val changeDirectionChar = '@'
val addArrowChar = 'V'
val deadSpellChar = 'X'
val quarterTurnSpellChar = 'Q'
val noMoveSpellChar = '#'

val choicesCellSize = cellWidth

