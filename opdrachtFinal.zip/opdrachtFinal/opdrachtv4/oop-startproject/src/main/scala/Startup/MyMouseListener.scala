package Startup

import gamelib.SimpleMouseListener

class MyMouseListener extends SimpleMouseListener{
  def onEvent(x: Int, y: Int): Unit = //zal opgeroepen worden elkens ker dat je klikt op de muis
    game.tryClick(x, y)
}
